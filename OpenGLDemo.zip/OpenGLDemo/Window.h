#pragma once
#include <string>


GLFWwindow* InitWindow(int width, int height, std::string windowName);