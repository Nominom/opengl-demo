#include "light.h"



Light::Light() {
	color = { 1,1,1 };
	direction = { -3 , -2, 0 };
}